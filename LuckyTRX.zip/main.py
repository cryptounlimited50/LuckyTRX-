# main.py - Telegram Bot Entry Point (Simplified Structure)
from telegram import Bot, Update
from telegram.ext import CommandHandler, MessageHandler, Filters, Updater

def start(update, context):
    update.message.reply_text("🎉 Welcome to LuckyTRX!
Send 1 TRX to enter the draw.")

def main():
    TOKEN = "YOUR_BOT_TOKEN"
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
